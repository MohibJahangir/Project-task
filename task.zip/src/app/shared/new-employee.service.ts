import { Injectable } from '@angular/core';
import { FormGroup,FormControl ,Validators} from '@angular/forms';
@Injectable({
  providedIn: 'root'
})
export class NewEmployeeService {

  constructor() { }

  form: FormGroup=new FormGroup({
    $key:new FormControl(null),
    name: new FormControl('',[Validators.required]),
    dateOfBirth: new FormControl('',[Validators.required]),
    mobileNo: new FormControl('', [Validators.required, Validators.minLength(11), Validators.pattern("^((\\+92)?(0092)?(92)?(0)?)(3)([0-9]{9})$")]),
    nationality: new FormControl('',[Validators.required]),
    religion: new FormControl('',[Validators.required]),
    appointmentDate: new FormControl('',[Validators.required]),
    passportNo: new FormControl('',[Validators.required]),
    department: new FormControl('',[Validators.required]),
    city: new FormControl('', Validators.pattern('[a-zA-Z]*')),
    fatherName: new FormControl('',[Validators.required]),
    nicNo: new FormControl('',[Validators.required,Validators.pattern("^[0-9]{5}[-]{1}[0-9]{7}[-]{1}[0-9]{1}")]),
    landLineNo: new FormControl('',[Validators.required]),
    gender: new FormControl('',[Validators.required]),
    active: new FormControl('',[Validators.required]),
    joiningDate: new FormControl('',[Validators.required]),
    designation: new FormControl('',[Validators.required]),
    streetAddress: new FormControl('',[Validators.required])
  });
  
};
export interface Countries {
  code: string
  code3: string
  name: string
  number: string
}
