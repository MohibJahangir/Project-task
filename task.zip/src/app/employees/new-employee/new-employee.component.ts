("strict mode")
import { Component, OnInit } from '@angular/core';
import { countries } from 'src/app/shared/countrydata';
import { NewEmployeeService } from 'src/app/shared/new-employee.service';
//import { Router } from '@angular/router';
@Component({
  selector: 'app-new-employee',
  templateUrl: './new-employee.component.html',
  styleUrls: ['./new-employee.component.css']
})
export class NewEmployeeComponent implements OnInit {
  data: any = {};
  allData: any = JSON.parse(localStorage.getItem('formdata') || '{}');
  constructor(public service: NewEmployeeService)
   { }
  religions=[
    {id: 1,value:'Islam' },
    {id:2,value :'Christian'},
    {id:3,value:'hindu'}
  ];
  designations=[
    {id: 1,value:'Teacher' },
    {id:2,value :'Admin'},
    {id:3,value:'Lab attendent'}
  ];
  public countries:any=countries
  ngOnInit(): void {
    
  }
  OnlyNumbersAllowed(event:any):boolean
  {
    const charcode=(event.which)?event.which:event.keycode;
if(charcode>31&&(charcode<48||charcode>57))
      return false;
  
  return true;
}
OnlyAlphabetsAllowed(event:any):boolean
{
  const charcode=(event.which)?event.which:event.keycode;
if(((charcode>64&&charcode<91)||charcode>96&&charcode<123)||charcode==32)
    return true;

return false;
}

}
